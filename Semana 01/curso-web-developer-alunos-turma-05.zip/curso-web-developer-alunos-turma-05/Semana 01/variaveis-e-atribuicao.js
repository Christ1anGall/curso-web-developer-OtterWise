// Variáveis e atribuição

let gaveta = "olá, lara";

gaveta = "olá, hynara";

console.log(gaveta);

var gaveta2 = "Olá, mundo"; // Não utilizem var

const gaveta3 = "Olá, mundo";
