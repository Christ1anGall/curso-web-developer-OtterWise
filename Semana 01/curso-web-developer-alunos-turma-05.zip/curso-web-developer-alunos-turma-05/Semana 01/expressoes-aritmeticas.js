// Expressões Aritméticas

// Soma

let somatorio = 100 + 100;

console.log(10 + 10 + 10 + -2 + 8.5);
console.log(somatorio);

// Subtração

console.log(10 - 5);
console.log(10 - -5);

// Multiplicação

console.log(2 * 2);

// Divisão

console.log(10 / 2);

// Potência

console.log(3 ** 3);

// Resto da divisão

console.log(10 % 2);

// Exemplos

console.log((42 * 10) / 2);
console.log((10 + 5) / 2);
