// operadores de comparação

// Equidade

console.log("5" == 5);
console.log("5" === 5);

console.log("5" != 5);
console.log("5" !== 5);

// Menor, menor igual, maior e maior igual

console.log(5 < 10);
console.log(5 <= 5);

console.log(10 > 5);
console.log(10 >= 10);
