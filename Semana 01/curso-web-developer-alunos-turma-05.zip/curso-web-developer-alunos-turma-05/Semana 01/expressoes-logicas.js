// Expressões lógicas

// AND (&&)
let x = 12;

if (x >= 0 && x <= 10) {
  console.log("Número está entre 0 e 10");
} else {
  console.log("Número não está entre 0 e 10");
}

// OR (||)

if (x < 0 || x > 10) {
  console.log("O número está fora do intervalo 0 - 10");
} else {
  console.log("O número está dentro do intervalo 0 - 10");
}
