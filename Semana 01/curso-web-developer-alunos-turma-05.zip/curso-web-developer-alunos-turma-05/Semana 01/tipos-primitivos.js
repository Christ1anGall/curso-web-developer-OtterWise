// String

console.log("Olá, mundo");
console.log("");
console.log("Ola\nmundo");
console.log("40");

// Number

console.log(40);
console.log(1.5);
console.log(-40);

// Booleans

console.log(true);
console.log(false);

// Null

console.log(null);
let gaveta = null;

// Undefined

console.log(undefined);
