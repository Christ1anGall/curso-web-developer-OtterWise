// Crie um programa que some os números 5, 10 e 15. Salve o resultado em uma variável e imprima no console.

let somatorio = 5 + 10 + 15;

console.log(somatorio);
