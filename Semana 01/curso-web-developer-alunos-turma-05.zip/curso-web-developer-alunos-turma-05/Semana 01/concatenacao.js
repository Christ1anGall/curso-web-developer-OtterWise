// concatenação de strings

let ola = "Olá";
let mundo = "mundo";

console.log("Olá" + ", " + "mundo");
console.log(ola + ", " + mundo);

console.log("Olá, eu sou o joão e tenho " + 27 + " anos");

console.log(27 + "10");
